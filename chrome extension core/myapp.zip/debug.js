document.write("Some text goes here");
document.write("<br></br>"); //writing html through js -> this is a line break
document.write("More text after a line break goes here");
